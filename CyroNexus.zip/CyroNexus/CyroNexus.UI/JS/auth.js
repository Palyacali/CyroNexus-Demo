// Sayfa yüklendiğinde splash screen animasyonu
function ensureToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    return container;
}

function inferToastType(message) {
    const msg = (message || '').toLowerCase();
    if (msg.includes('basarili') || msg.includes('guncellendi') || msg.includes('gonderildi')) return 'success';
    if (msg.includes('hata') || msg.includes('failed') || msg.includes('gecersiz') || msg.includes('uyusmuyor') || msg.includes('cooldown')) return 'error';
    return 'info';
}

function showToast(message, type) {
    const container = ensureToastContainer();
    const toast = document.createElement('div');
    const toastType = type || inferToastType(message);
    toast.className = `toast toast-${toastType}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 2800);
}

window.alert = (message) => showToast(message);

document.addEventListener('DOMContentLoaded', () => {
    const loader = document.getElementById('loader-progress');
    const status = document.getElementById('loader-status');
    const splash = document.getElementById('splash-screen');
    const main = document.getElementById('main-container');
    
    let progress = 0;
    const stages = ["INITIALIZING_CORE", "SYNCING_DATABASE", "DECRYPTING_ASSETS", "SYSTEM_STABLE"];

    const loadingInterval = setInterval(() => {
        progress += Math.random() * 6;
        if (progress > 100) progress = 100;
        
        if (loader) loader.style.width = `${progress}%`;
        
        const currentStage = stages[Math.floor((progress / 101) * stages.length)];
        if (status && status.innerText !== currentStage) {
            status.innerText = currentStage;
        }

        if (progress >= 100) {
            clearInterval(loadingInterval);
            setTimeout(() => {
                if(splash) {
                    splash.style.opacity = '0';
                    splash.style.transform = 'scale(1.05)';
                }
                setTimeout(() => {
                    if(splash) splash.classList.add('hidden');
                    if (main) {
                        main.classList.remove('hidden');
                        main.style.animation = "fadeIn 1s ease forwards";
                    }
                }, 800);
            }, 500);
        }
    }, 80);
});

// --- UI KONTROLLERİ ---
function openForgotModal() {
    document.getElementById('forgot-modal').classList.remove('hidden');
    document.getElementById('recovery-step-1').classList.remove('hidden');
    document.getElementById('recovery-step-2').classList.add('hidden');
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.classList.add('hidden');
}

function showTab(type) {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const verifyForm = document.getElementById('verify-form');
    const btnLogin = document.getElementById('btn-login');
    const btnRegister = document.getElementById('btn-register');

    loginForm.classList.add('hidden');
    registerForm.classList.add('hidden');
    verifyForm.classList.add('hidden');
    btnLogin.classList.remove('active');
    btnRegister.classList.remove('active');

    if (type === 'login') {
        loginForm.classList.remove('hidden');
        btnLogin.classList.add('active');
    } else if (type === 'verify') {
        verifyForm.classList.remove('hidden');
    } else {
        registerForm.classList.remove('hidden');
        btnRegister.classList.add('active');
    }
}

// --- AUTH İŞLEMLERİ ---

async function handleLogin() {
    const username = document.getElementById('l-user').value.trim();
    const password = document.getElementById('l-pass').value;

    if (!username || !password) return alert("Eksik bilgi!");

    try {
        const res = await fetch("http://localhost:5000/api/auth/login", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Username: username, Password: password })
        });

        const data = await res.json();
        if (res.ok) {
            localStorage.setItem('cyro_user', JSON.stringify(data));
            window.location.href = "dashboard.html";
        } else {
            alert(data.message || "Giriş başarısız!");
        }
    } catch (err) {
        alert("Sunucuya bağlanılamadı!");
    }
}

async function handleRegister() {
    const username = document.getElementById('r-user').value.trim();
    const email = document.getElementById('r-email').value.trim();
    const password = document.getElementById('r-pass').value;
    const vkey = document.getElementById('r-vkey').value;

    if (!username || !email || !password) return alert("Eksik bilgi!");

    try {
        const res = await fetch("http://localhost:5000/api/auth/register", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Username: username, Email: email, Password: password, VaultKeyHash: vkey })
        });

        const data = await res.json();
        if (res.ok) {
            localStorage.setItem('pendingEmail', email);
            alert("Kayıt başarılı! E-posta doğrulaması gerekiyor.");
            showTab('verify');
            document.getElementById('v-email').value = email;
        } else {
            alert(data.message || "Kayıt başarısız!");
        }
    } catch (err) {
        alert("Sunucu hatası!");
    }
}

async function handleVerify() {
    const email = localStorage.getItem('pendingEmail') || "";
    const codeInput = document.getElementById('v-code');
    const code = codeInput ? codeInput.value.trim() : "";

    if (!email || !code) return alert("Eksik bilgi!");
    if (code.length !== 6) { if (codeInput) codeInput.value = ""; return alert("Kod 6 haneli olmali!"); }

    try {
        const res = await fetch("http://localhost:5000/api/auth/verify-email", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Email: email, Code: code })
        });

        const data = await res.json();
        if (res.ok) {
            alert("Dogrulama basarili. Giris yapabilirsiniz.");
            if (codeInput) codeInput.value = "";
            localStorage.removeItem('pendingEmail');
            showTab('login');
        } else {
            if (codeInput) codeInput.value = "";
            if (res.status === 429) alert("COOLDOWN_ACTIVE: 1 saat bekleyin.");
            else alert(data.message || "Dogrulama basarisiz!");
        }
    } catch (err) {
        alert("Sunucuya baglanilamadi!");
    }
}

async function handleResendCode() {
    const email = localStorage.getItem('pendingEmail') || "";
    if (!email) return alert("E-posta bilgisi yok.");

    try {
        const res = await fetch("http://localhost:5000/api/auth/resend-verification", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Email: email })
        });

        if (res.ok) {
            const codeInput = document.getElementById('v-code');
            if (codeInput) codeInput.value = "";
            alert("Kod tekrar gonderildi.");
        } else {
            const err = await res.json().catch(() => ({}));
            if (res.status === 429) {
                alert("COOLDOWN_ACTIVE: 1 saat bekleyin.");
            } else {
                alert(err.message || "Tekrar gonderme basarisiz!");
            }
        }
    } catch (err) {
        alert("Sunucuya baglanilamadi!");
    }
}

async function requestRecovery() {
    const emailInput = document.getElementById('recovery-id');
    const email = emailInput ? emailInput.value.trim() : "";
    if (!email) return alert("E-posta giriniz.");

    try {
        const res = await fetch("http://localhost:5000/api/auth/request-recovery", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Email: email })
        });

        if (res.ok) {
            document.getElementById('recovery-step-1').classList.add('hidden');
            document.getElementById('recovery-step-2').classList.remove('hidden');
            const codeInput = document.getElementById('recovery-input-code');
            if (codeInput) codeInput.value = "";
            alert("Kurtarma kodu gonderildi.");
        } else {
            const err = await res.json().catch(() => ({}));
            if (res.status === 429) {
                alert("COOLDOWN_ACTIVE: 1 saat bekleyin.");
            } else {
                alert(err.message || "Kurtarma talebi basarisiz!");
            }
        }
    } catch (err) {
        alert("Sunucuya baglanilamadi!");
    }
}

async function submitReset() {
    const codeInput = document.getElementById('recovery-input-code');
    const code = codeInput ? codeInput.value.trim() : "";
    const newPass = document.getElementById('rec-new-pass').value;
    const confPass = document.getElementById('rec-conf-pass').value;

    if (!code || !newPass || !confPass) return alert("Eksik bilgi!");
    if (newPass !== confPass) return alert("Sifreler uyusmuyor!");

    try {
        const res = await fetch("http://localhost:5000/api/auth/reset-password", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ Code: code, NewPassword: newPass, ConfirmPassword: confPass })
        });

        if (res.ok) {
            alert("Sifre guncellendi. Giris yapabilirsiniz.");
            if (codeInput) codeInput.value = "";
            document.getElementById('rec-new-pass').value = "";
            document.getElementById('rec-conf-pass').value = "";
            closeModal('forgot-modal');
            showTab('login');
        } else {
            const err = await res.json().catch(() => ({}));
            if (codeInput) codeInput.value = "";
            if (res.status === 429) {
                alert("COOLDOWN_ACTIVE: 1 saat bekleyin.");
            } else {
                alert(err.message || "Sifre sifirlama basarisiz!");
            }
        }
    } catch (err) {
        alert("Sunucuya baglanilamadi!");
    }
}
