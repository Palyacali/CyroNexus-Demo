window.onload = () => {
    const bar = document.querySelector('.progress');
    const splash = document.getElementById('splash-screen');
    const main = document.getElementById('main-container');
    const status = document.getElementById('status-text');

    let progress = 0;

    const boot = setInterval(() => {
        progress += Math.floor(Math.random() * 10) + 5;
        if (bar) bar.style.width = progress + '%';

        if (progress >= 100) {
            clearInterval(boot);
            if (status) status.innerText = "SİSTEM ERİŞİME HAZIR";
            
            setTimeout(() => {
                splash.style.opacity = '0';
                splash.style.transition = 'opacity 0.8s ease';
                
                setTimeout(() => {
                    splash.classList.add('hidden');
                    main.classList.remove('hidden');
                    // Tıklama sorununu önlemek için flex yapısını zorla
                    main.style.display = 'flex';
                    if (typeof showTab === 'function') showTab('login');
                }, 800);
            }, 500);
        }
    }, 150);
};

// js/auth.js içindeki showTab'ı da buraya yedekliyoruz
function showTab(type) {
    document.querySelectorAll('.auth-content').forEach(c => c.classList.add('hidden'));
    document.getElementById(`${type}-form`).classList.remove('hidden');
    
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(`btn-${type}`).classList.add('active');
}