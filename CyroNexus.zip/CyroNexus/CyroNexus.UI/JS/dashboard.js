// --- GLOBALS ---
let vaultItems = [];
let lastSecTarget = "";

function ensureToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    return container;
}

function inferToastType(message) {
    const msg = (message || '').toLowerCase();
    if (msg.includes('basarili') || msg.includes('guncellendi') || msg.includes('gonderildi')) return 'success';
    if (msg.includes('hata') || msg.includes('failed') || msg.includes('gecersiz') || msg.includes('uyusmuyor') || msg.includes('cooldown')) return 'error';
    return 'info';
}

function showToast(message, type) {
    const container = ensureToastContainer();
    const toast = document.createElement('div');
    const toastType = type || inferToastType(message);
    toast.className = `toast toast-${toastType}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 2800);
}

window.alert = (message) => showToast(message);

function confirmToast(message) {
    return new Promise((resolve) => {
        const container = ensureToastContainer();
        const overlay = document.createElement('div');
        overlay.className = 'toast-overlay';
        document.body.appendChild(overlay);

        const toast = document.createElement('div');
        toast.className = 'toast toast-info toast-confirm';

        const text = document.createElement('div');
        text.className = 'toast-text';
        text.textContent = message;

        const actions = document.createElement('div');
        actions.className = 'toast-actions';

        const yesBtn = document.createElement('button');
        yesBtn.className = 'toast-btn toast-yes';
        yesBtn.textContent = 'EVET';

        const noBtn = document.createElement('button');
        noBtn.className = 'toast-btn toast-no';
        noBtn.textContent = 'HAYIR';

        actions.appendChild(yesBtn);
        actions.appendChild(noBtn);
        toast.appendChild(text);
        toast.appendChild(actions);
        container.appendChild(toast);

        setTimeout(() => toast.classList.add('show'), 10);

        const cleanup = (result) => {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.remove();
                overlay.remove();
            }, 200);
            resolve(result);
        };

        yesBtn.onclick = () => cleanup(true);
        noBtn.onclick = () => cleanup(false);
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    let user = JSON.parse(localStorage.getItem('cyro_user'));
    if (!user) { window.location.href = "index.html"; return; }

    const userId = user.id || user.Id;
    try {
        const res = await fetch(`http://localhost:5000/api/user/get-profile/${userId}`);
        if (res.ok) {
            const freshData = await res.json();
            localStorage.setItem('cyro_user', JSON.stringify(freshData));
            user = freshData;
            addLog("SYSTEM: profile synced");
        }
    } catch (err) {
        addLog("WARN: sync failed");
    }

    // Normalize casing for legacy payloads
    if (!user.username && user.Username) user.username = user.Username;
    if (!user.email && user.Email) user.email = user.Email;
    localStorage.setItem('cyro_user', JSON.stringify(user));

    syncUserSettings(user);
    startClock();
    loadVaultItems();
});

// --- SETTINGS ---
async function submitUsernameChange() {
    const newUsername = document.getElementById('new-username-input').value;
    if (!newUsername) return;

    const user = JSON.parse(localStorage.getItem('cyro_user'));
    const payload = { UserId: user.id || user.Id, NewUsername: newUsername };

    try {
        const res = await fetch("http://localhost:5000/api/user/update-profile", {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            user.username = newUsername;
            localStorage.setItem('cyro_user', JSON.stringify(user));
            syncUserSettings(user);
            addLog(`USERNAME_UPDATED: ${newUsername}`);
            closeModal('username-modal');
        }
    } catch (err) { addLog("ERROR: username update failed"); }
}

// --- EMAIL UPDATE ---
async function sendVerification() {
    const inputEl = document.getElementById('sec-new-value');
    const newVal = inputEl ? inputEl.value.trim() : "";
    const target = newVal || lastSecTarget;
    if (!target) return alert("Deger girilmedi");

    if (newVal) lastSecTarget = newVal;

    const user = JSON.parse(localStorage.getItem('cyro_user'));

    try {
        const res = await fetch("http://localhost:5000/api/user/send-code", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: user.id || user.Id, target })
        });

        if (res.ok) {
            document.getElementById('sec-input-area').classList.add('hidden');
            document.getElementById('sec-verify-area').classList.remove('hidden');
            const codeInput = document.getElementById('sec-verify-code');
            if (codeInput) codeInput.value = "";
            addLog("EMAIL code sent");
        } else {
            if (res.status === 429) {
                alert("COOLDOWN_ACTIVE: 1 saat bekleyin.");
            }
            addLog("ERROR: code send failed");
        }
    } catch (err) { addLog("ERROR: API connection lost"); }
}

async function verifyAndSave() {
    const user = JSON.parse(localStorage.getItem('cyro_user'));
    const codeInput = document.getElementById('sec-verify-code');
    const code = codeInput ? codeInput.value : "";
    const newValue = document.getElementById('sec-new-value').value;

    if (!code) return alert("Onay kodu gir");
    if (code.length !== 6) { if (codeInput) codeInput.value = ""; return alert("Kod 6 haneli olmali"); }

    const payload = { UserId: user.id || user.Id, Code: code, NewEmail: newValue };

    try {
        const res = await fetch("http://localhost:5000/api/user/update-email", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            user.email = newValue;
            localStorage.setItem('cyro_user', JSON.stringify(user));
            syncUserSettings(user);
            addLog("EMAIL updated");
            if (codeInput) codeInput.value = "";
            document.getElementById('sec-new-value').value = "";
            closeSecModal();
            alert("Email guncellendi");
        } else {
            if (codeInput) codeInput.value = "";
            if (res.status === 429) {
                alert("COOLDOWN_ACTIVE: 1 saat bekleyin.");
            } else {
                alert("Onay kodu gecersiz");
            }
        }
    } catch (err) { addLog("ERROR: email update failed"); }
}

async function submitVaultKeyChange() {
    const user = JSON.parse(localStorage.getItem('cyro_user'));
    const oldKey = document.getElementById('old-vkey-input').value;
    const newKey = document.getElementById('new-vkey-input').value;

    const payload = { UserId: user.id || user.Id, OldKey: oldKey, NewKey: newKey };

    try {
        const res = await fetch("http://localhost:5000/api/user/update-vault-key", {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            addLog("VAULT key updated");
            closeModal('vaultkey-modal');
        }
    } catch (err) { addLog("ERROR: vault key update failed"); }
}

async function updatePassword() {
    const user = JSON.parse(localStorage.getItem('cyro_user'));
    const oldP = document.getElementById('old-pass').value;
    const newP = document.getElementById('new-pass').value;
    const confP = document.getElementById('confirm-pass').value;

    if (newP !== confP) return alert("Sifreler uyusmuyor");

    const payload = { UserId: user.id || user.Id, OldPassword: oldP, NewPassword: newP };

    try {
        const res = await fetch("http://localhost:5000/api/user/change-password", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            addLog("PASSWORD updated");
            closePassModal();
        } else {
            alert("Eski sifre hatali");
        }
    } catch (err) { addLog("ERROR: password update failed"); }
}

// --- MODALS ---
function openSecurityModal() {
    document.getElementById('sec-modal-title').innerText = "EMAIL_PROTOKOLU";
    document.getElementById('sec-new-value').placeholder = "YENI_EPOSTA";
    document.getElementById('sec-new-value').value = "";
    lastSecTarget = "";
    document.getElementById('sec-verify-code').value = "";
    document.getElementById('sec-input-area').classList.remove('hidden');
    document.getElementById('sec-verify-area').classList.add('hidden');
    document.getElementById('security-modal').classList.remove('hidden');
}

function openProfileModal(type) {
    if (type === 'username') {
        document.getElementById('username-modal').classList.remove('hidden');
    }
}

function openPasswordModal() {
    document.getElementById('password-modal').classList.remove('hidden');
}

function openVaultKeyModal() {
    document.getElementById('vaultkey-modal').classList.remove('hidden');
}

function unlockVault() {
    const keyInput = document.getElementById('vault-key-input');
    if (!keyInput || keyInput.value.length === 0) return;

    document.getElementById('vault-lock-screen').classList.add('hidden');
    document.getElementById('vault-content').classList.remove('hidden');
    const addBtn = document.getElementById('add-btn-vault');
    if (addBtn) addBtn.classList.remove('hidden');

    loadVaultItems();
}

function openVaultModal() {
    document.getElementById('modal-title').innerText = "VERI_MUHURLEME_PROTOKOLU";
    const btn = document.getElementById('main-vault-btn');
    if (btn) btn.innerText = "MUHURLE";
    if (btn) btn.onclick = saveVaultItem;
    document.getElementById('new-title').value = "";
    document.getElementById('new-val').value = "";
    document.getElementById('vault-modal').classList.remove('hidden');
}

function closeVaultModal() {
    document.getElementById('vault-modal').classList.add('hidden');
}

function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
function closeSecModal() { document.getElementById('security-modal').classList.add('hidden'); }
function closePassModal() { document.getElementById('password-modal').classList.add('hidden'); }

// --- VAULT ---
async function loadVaultItems() {
    const user = JSON.parse(localStorage.getItem('cyro_user'));
    if (!user) return;

    try {
        const res = await fetch(`http://localhost:5000/api/vault/${user.username || user.Username}`);
        if (res.ok) {
            vaultItems = await res.json();
            renderVaultItems();
        }
    } catch (err) { addLog("ERROR: vault load failed"); }
}

function renderVaultItems() {
    const list = document.getElementById('vault-list');
    if (!list) return;
    list.innerHTML = "";

    vaultItems.forEach(item => {
        const card = document.createElement('div');
        card.className = 'vault-card';
        const title = item.title || item.Title || "ITEM";
        const value = item.encryptedValue || item.EncryptedValue || "";
        const category = item.category || item.Category || "";
        const id = item.id || item.Id;
        const masked = "•".repeat(Math.max(6, Math.min(24, value.length || 8)));
        card.innerHTML = `
            <div class="vault-card-title">${title}</div>
            <div class="vault-card-value vault-value-text hidden-val" data-value="${value}">${masked}</div>
            <div class="vault-card-meta">${category}</div>
            <div class="vault-card-actions">
                <button class="cyro-btn-small" onclick="openEditModal('${id}')">DÜZENLE</button>
                <button class="cyro-btn-small" onclick="deleteItem('${id}')">SİL</button>
            </div>
        `;
        list.appendChild(card);

        const valEl = card.querySelector('.vault-card-value');
        if (valEl) {
            valEl.addEventListener('click', () => toggleVisibility(valEl));
        }
    });

    const count = document.getElementById('vault-count');
    if (count) count.innerText = String(vaultItems.length);
}

function toggleVisibility(el) {
    if (!el) return;
    const value = el.getAttribute('data-value') || "";
    const isHidden = el.classList.contains('hidden-val');

    if (isHidden) {
        el.classList.remove('hidden-val');
        el.textContent = value || "(boş)";
    } else {
        const masked = "•".repeat(Math.max(6, Math.min(24, value.length || 8)));
        el.classList.add('hidden-val');
        el.textContent = masked;
    }
}

async function saveVaultItem() {
    const user = JSON.parse(localStorage.getItem('cyro_user'));
    const title = document.getElementById('new-title').value;
    const value = document.getElementById('new-val').value;
    const category = document.getElementById('new-cat').value;

    if (!title || !value) return alert("Bos alan var");

    const payload = {
        Id: crypto.randomUUID(),
        Title: title,
        EncryptedValue: value,
        Category: category,
        Owner: user.username || user.Username,
        UpdatedAt: new Date().toISOString()
    };

    try {
        const res = await fetch("http://localhost:5000/api/vault/add", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            closeVaultModal();
            loadVaultItems();
            addLog("VAULT item saved");
        }
    } catch (err) { addLog("ERROR: vault save failed"); }
}

function openEditModal(id) {
    const item = vaultItems.find(v => (v.id || v.Id) === id);
    if (!item) return;

    document.getElementById('modal-title').innerText = "VERI_DUZENLEME_PROTOKOLU";
    const btn = document.getElementById('main-vault-btn');
    if (btn) btn.innerText = "GUNCELLE";
    if (btn) btn.onclick = () => updateVaultItem(id);

    document.getElementById('new-title').value = item.title || item.Title || "";
    document.getElementById('new-val').value = item.encryptedValue || item.EncryptedValue || "";
    document.getElementById('new-cat').value = item.category || item.Category || "Secret";

    document.getElementById('vault-modal').classList.remove('hidden');
}

async function updateVaultItem(id) {
    const user = JSON.parse(localStorage.getItem('cyro_user'));
    const title = document.getElementById('new-title').value;
    const value = document.getElementById('new-val').value;
    const category = document.getElementById('new-cat').value;

    if (!title || !value) return alert("Bos alan var");

    const payload = {
        Id: id,
        Title: title,
        EncryptedValue: value,
        Category: category,
        Owner: user.username || user.Username,
        UpdatedAt: new Date().toISOString()
    };

    try {
        const res = await fetch("http://localhost:5000/api/vault/update", {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            closeVaultModal();
            loadVaultItems();
            addLog("VAULT item updated");
        }
    } catch (err) { addLog("ERROR: vault update failed"); }
}

async function deleteItem(id) {
    const ok = await confirmToast("Silmek istiyor musun?");
    if (!ok) return;

    try {
        const res = await fetch(`http://localhost:5000/api/vault/delete/${id}`, {
            method: 'DELETE'
        });

        if (res.ok) {
            loadVaultItems();
            addLog("VAULT item deleted");
        }
    } catch (err) { addLog("ERROR: vault delete failed"); }
}

// --- HELPERS ---
function syncUserSettings(user) {
    const opName = document.getElementById('display-op-name');
    if (opName) {
        const name = user.username || user.Username;
        opName.innerText = name ? name.toUpperCase() : "UNKNOWN";
    }

    const displayUsername = document.getElementById('display-username');
    if (displayUsername) {
        const name = user.username || user.Username || "";
        displayUsername.innerText = name.toUpperCase();
        document.getElementById('display-email').innerText = user.email || user.Email || "EKLENMEMIS";
    }
}

function addLog(msg) {
    const logs = document.getElementById('nexus-logs');
    if (!logs) return;
    const div = document.createElement('div');
    div.innerText = `> ${new Date().toLocaleTimeString()}: ${msg}`;
    logs.prepend(div);
}

function startClock() { setInterval(() => { 
    const el = document.getElementById('live-clock');
    if(el) el.innerText = new Date().toLocaleTimeString(); 
}, 1000); }

async function handleLogout() {
    try { await fetch("http://localhost:5000/api/auth/logout", { method: "POST" }); } catch (err) {}
    localStorage.removeItem("cyro_user");
    window.location.href = "index.html";
}

function switchView(target, btn) {
    document.querySelectorAll('.view-pane').forEach(p => p.classList.remove('active'));
    const next = document.getElementById(`view-${target}`);
    if (next) next.classList.add('active');

    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    addLog(`DISPLAY_MODE: ${target.toUpperCase()}`);
}
