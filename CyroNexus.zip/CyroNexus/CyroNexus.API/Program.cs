using System.Text.Json;
using System.Collections.Concurrent;
using System.Linq;
using CyroNexus.API.Models;
using CyroNexus.API.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;

var dbPath = "Data/users.json";
var pendingDbPath = "Data/pending-users.json";
var pendingLock = new object();

List<User> LoadPending()
{
    lock (pendingLock)
    {
        if (!File.Exists(pendingDbPath)) return new List<User>();
        var json = File.ReadAllText(pendingDbPath);
        return JsonSerializer.Deserialize<List<User>>(json) ?? new List<User>();
    }
}

void SavePending(List<User> pending)
{
    lock (pendingLock)
    {
        var json = JsonSerializer.Serialize(pending, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(pendingDbPath, json);
    }
}
var builder = WebApplication.CreateBuilder(args);
// --- CORS AYARLARI (Geliï¿½tirilmiï¿½) ---
builder.Services.AddCors(options => {
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins("http://localhost:5000")
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials());
});
builder.Services.AddControllers()
    .AddJsonOptions(options => {
        options.JsonSerializerOptions.PropertyNamingPolicy = null; 
    });
builder.Services.AddSingleton<AuthService>();
builder.Services.AddSingleton<SecurityLogService>();
builder.Services.AddSingleton<EmailService>();

// --- SESSION (Persist 7 days, HttpOnly Cookie) ---
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromDays(7);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.Name = "cyro_sid";
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
});

// DataProtection keys persist so EXE restart doesn't invalidate sessions
builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(AppContext.BaseDirectory, "dataprotection-keys")));
var app = builder.Build();

// --- MIDDLEWARE SIRALAMASI (Kritik!) ---
app.UseStaticFiles();

// --- UI STATIC FILES (CyroNexus.UI) ---
var uiRootCandidates = new[]
{
    Path.Combine(AppContext.BaseDirectory, "CyroNexus.UI"),
    Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "CyroNexus.UI")
}.Select(Path.GetFullPath);

var uiRoot = uiRootCandidates.FirstOrDefault(Directory.Exists);
if (uiRoot != null)
{
    var uiProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(uiRoot);
    app.UseStaticFiles(new StaticFileOptions
    {
        FileProvider = uiProvider,
        RequestPath = ""
    });
    app.MapFallbackToFile("/index.html", new StaticFileOptions
    {
        FileProvider = uiProvider
    });
}

app.UseRouting();
app.UseCors(); app.UseSession(); // Cors her zaman Routing'den sonra, Map'lerden ï¿½nce olmalï¿½

// --- TEST ROUTE ---
app.MapGet("/", () => "CyroNexus API Engine: ONLINE");
// --- COOLDOWN (3 attempts -> 1 hour lock) ---
const int CooldownMaxAttempts = 3;
var cooldownDuration = TimeSpan.FromHours(1);
var cooldown = new ConcurrentDictionary<string, CooldownState>();

bool IsLocked(string key, out DateTime lockedUntil)
{
    lockedUntil = DateTime.MinValue;
    if (cooldown.TryGetValue(key, out var state))
    {
        if (state.LockedUntil != null && state.LockedUntil > DateTime.UtcNow)
        {
            lockedUntil = state.LockedUntil.Value;
            return true;
        }
        if (state.LockedUntil != null && state.LockedUntil <= DateTime.UtcNow)
        {
            cooldown.TryRemove(key, out _);
        }
    }
    return false;
}

void RegisterFailure(string key)
{
    var now = DateTime.UtcNow;
    cooldown.AddOrUpdate(key,
        _ => new CooldownState { FailCount = 1 },
        (_, s) =>
        {
            if (s.LockedUntil != null && s.LockedUntil > now) return s;
            s.FailCount++;
            if (s.FailCount >= CooldownMaxAttempts)
            {
                s.FailCount = 0;
                s.LockedUntil = now.Add(cooldownDuration);
            }
            return s;
        });
}

void RegisterSuccess(string key)
{
    cooldown.TryRemove(key, out _);
}

// --- 1. AUTH: KAYIT (REGISTER) ---
app.MapPost("/api/auth/register", async (User newUser, AuthService auth, EmailService emailService) => {
    var users = await auth.GetUsersAsync();
    var pending = LoadPending();

    if (users.Any(u => u.Username.ToLower() == newUser.Username.ToLower()) ||
        pending.Any(u => u.Username.ToLower() == newUser.Username.ToLower()))
        return Results.BadRequest(new { message = "Bu operatï¿½r adï¿½ sistemde zaten kayï¿½tlï¿½." });

    if (users.Any(u => u.Email.ToLower() == newUser.Email.ToLower()) ||
        pending.Any(u => u.Email.ToLower() == newUser.Email.ToLower()))
        return Results.BadRequest(new { message = "Bu e-posta adresi baï¿½ka bir operatï¿½re ait." });

    newUser.Password = auth.EncryptPassword(newUser.Password);

    if (!string.IsNullOrEmpty(newUser.VaultKeyHash))
        newUser.VaultKeyHash = auth.HashPassword(newUser.VaultKeyHash);

    newUser.VerificationCode = auth.GenerateVerificationCode();
    newUser.VerificationCodeExpiresAt = DateTime.UtcNow.AddMinutes(5);
    newUser.IsEmailVerified = false;
    newUser.CreatedAt = DateTime.Now;
    newUser.Rank = "Operator";

    var sent = await emailService.SendVerificationCodeAsync(newUser.Email, newUser.VerificationCode);
    if (!sent)
        return Results.Problem("EMAIL_SEND_FAILED");

    pending.Add(newUser);
    SavePending(pending);

    return Results.Ok(new { message = "Kayï¿½t baï¿½arï¿½lï¿½. E-posta doï¿½rulama kodu gï¿½nderildi.", email = newUser.Email });
});

// --- 2. AUTH: DOï¿½RULAMA (VERIFY) ---
app.MapPost("/api/auth/verify-email", async (VerifyRequest req, AuthService auth, SecurityLogService log, HttpContext http) => {
    var users = await auth.GetUsersAsync();
    var pending = LoadPending();
    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    var email = req.Email?.Trim().ToLowerInvariant() ?? "";
    var key = $"{email}|{ip}";

    if (IsLocked(key, out var lockedUntil))
        return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);

#pragma warning disable CS8602 // Dereference of a possibly null reference.
    var pendingUser = pending.FirstOrDefault(u => u.Email.Trim().Equals(req.Email.Trim(), StringComparison.CurrentCultureIgnoreCase));
#pragma warning restore CS8602 // Dereference of a possibly null reference.

    if (pendingUser == null || pendingUser.VerificationCode != req.Code)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
#pragma warning disable CS8604 // Possible null reference argument.
        await log.LogAsync("EMAIL_VERIFY_FAIL", pendingUser?.Id, pendingUser?.Username ?? req.Email, ip, "invalid_code");
#pragma warning restore CS8604 // Possible null reference argument.
        return Results.BadRequest(new { message = "Geçersiz kod veya e-posta eşleşmesi." });
    }

    if (pendingUser.VerificationCodeExpiresAt == null || pendingUser.VerificationCodeExpiresAt < DateTime.UtcNow)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
        await log.LogAsync("EMAIL_VERIFY_FAIL", pendingUser.Id, pendingUser.Username, ip, "expired_code");
        return Results.BadRequest(new { message = "Doğrulama kodu süresi doldu." });
    }

    pendingUser.IsEmailVerified = true;
    pendingUser.VerificationCode = null;
    pendingUser.VerificationCodeExpiresAt = null;

    users.Add(pendingUser);
    await auth.SaveUsersAsync(users);

#pragma warning disable CS8602 // Dereference of a possibly null reference.
    _ = pending.RemoveAll(u => u.Email.Trim().Equals(req.Email.Trim(), StringComparison.CurrentCultureIgnoreCase));
#pragma warning restore CS8602 // Dereference of a possibly null reference.
    SavePending(pending);

    RegisterSuccess(key);

    await log.LogAsync("EMAIL_VERIFIED", pendingUser.Id, pendingUser.Username, ip, "");

    return Results.Ok(new { message = "Kimlik mühürlendi. Erişim sağlandı." });
});

app.MapPost("/api/auth/resend-verification", async (ResendVerificationRequest req, AuthService auth, SecurityLogService log, EmailService emailService, HttpContext http) => {
    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    var email = req.Email?.Trim().ToLowerInvariant() ?? "";
    var key = $"{email}|{ip}";

    if (IsLocked(key, out var lockedUntil))
        return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);

    var pending = LoadPending();
#pragma warning disable CS8602 // Dereference of a possibly null reference.
    var user = pending.FirstOrDefault(u => u.Email.Trim().Equals(req.Email.Trim(), StringComparison.CurrentCultureIgnoreCase));
#pragma warning restore CS8602 // Dereference of a possibly null reference.
    if (user == null)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
        return Results.NotFound(new { message = "NO_MATCH" });
    }

    user.VerificationCode = auth.GenerateVerificationCode();
    user.VerificationCodeExpiresAt = DateTime.UtcNow.AddMinutes(5);
    SavePending(pending);

    var sent = await emailService.SendVerificationCodeAsync(user.Email, user.VerificationCode);
    if (!sent)
        return Results.Problem("EMAIL_SEND_FAILED");

    RegisterSuccess(key);

    await log.LogAsync("EMAIL_VERIFY_RESEND", user.Id, user.Username, ip, "");

    return Results.Ok(new { message = "CODE_RESENT" });
});

app.MapPost("/api/auth/login", async (LoginRequest req, AuthService auth, SecurityLogService log, HttpContext http) => {
    var users = await auth.GetUsersAsync();
    var user = users.FirstOrDefault(u => u.Username.ToLower() == req.Username.ToLower());
    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";

    if (user == null)
    {
        await log.LogAsync("LOGIN_FAIL", null, req.Username, ip, "user_not_found");
        return Results.Unauthorized();
    }
    if (!auth.VerifyPassword(user.Password, req.Password))
    {
        await log.LogAsync("LOGIN_FAIL", user.Id, user.Username, ip, "bad_password");
        return Results.Unauthorized();
    }
    if (!user.IsEmailVerified) return Results.BadRequest(new { message = "E-posta doğrulanmamış." });

    http.Session.SetString("uid", user.Id.ToString());
    await log.LogAsync("LOGIN_SUCCESS", user.Id, user.Username, ip, "");

    return Results.Ok(new { id = user.Id, username = user.Username, email = user.Email, rank = user.Rank });
});

app.MapPost("/api/user/send-code", async (SendCodeRequest request, AuthService auth, EmailService emailService, HttpContext http) => 
{
    if (request == null || string.IsNullOrEmpty(request.UserId))
        return Results.BadRequest(new { message = "Hedef kullanıcı yok." });

    if (!Guid.TryParse(request.UserId, out var userGuid))
        return Results.BadRequest(new { message = "Geçersiz kullanıcı ID." });

    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    var key = $"{request.Target}|{ip}";

    if (IsLocked(key, out var lockedUntil))
        return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);

    var users = await auth.GetUsersAsync();
    var user = users.FirstOrDefault(u => u.Id == userGuid);
    if (user == null) return Results.NotFound();

    string code = new Random().Next(100000, 999999).ToString();
    user.VerificationCode = code;
    user.VerificationCodeExpiresAt = DateTime.UtcNow.AddMinutes(5);
    await auth.SaveUsersAsync(users);

    var sent = await emailService.SendSecurityCodeAsync(request.Target, code);
    if (!sent)
        return Results.Problem("EMAIL_SEND_FAILED");

    RegisterSuccess(key);
    return Results.Ok(new { message = "Kod gönderildi." });
});
app.MapPut("/api/user/update-profile", async (UpdateProfileRequest req, AuthService auth, SecurityLogService log, HttpContext http) => {
    var users = await auth.GetUsersAsync();
    var user = users.FirstOrDefault(u => u.Id == req.UserId);
    
    if (user == null) return Results.NotFound();

    user.Username = req.NewUsername ?? user.Username;

    await auth.SaveUsersAsync(users);

    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    await log.LogAsync("PROFILE_UPDATED", user.Id, user.Username, ip, "");

    return Results.Ok(new { message = "Profil gï¿½ncellendi." });
});
app.MapPost("/api/user/change-password", async (ChangePasswordRequest req, AuthService auth, SecurityLogService log, HttpContext http) => {
    var users = await auth.GetUsersAsync();
    var user = users.FirstOrDefault(u => u.Id == req.UserId);
    if (user == null) return Results.NotFound();

    if (!auth.VerifyPassword(user.Password, req.OldPassword))
        return Results.BadRequest(new { message = "Eski ï¿½ifre doï¿½rulanamadï¿½!" });

    user.Password = auth.EncryptPassword(req.NewPassword);
    await auth.SaveUsersAsync(users);

    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    await log.LogAsync("PASSWORD_CHANGED", user.Id, user.Username, ip, "");

    return Results.Ok(new { message = "ï¿½ifre gï¿½ncellendi." });
});
app.MapPut("/api/user/update-vault-key", async (UpdateVaultKeyRequest req, AuthService auth, SecurityLogService log, HttpContext http) => {
    var users = await auth.GetUsersAsync();
    var user = users.FirstOrDefault(u => u.Id == req.UserId);
    if (user == null) return Results.NotFound();

    var oldHash = auth.HashPassword(req.OldKey);
    if (user.VaultKeyHash != oldHash)
        return Results.BadRequest(new { message = "Mevcut anahtar doï¿½rulanamadï¿½!" });

    user.VaultKeyHash = auth.HashPassword(req.NewKey);
    await auth.SaveUsersAsync(users);

    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    await log.LogAsync("VAULT_KEY_UPDATED", user.Id, user.Username, ip, "");

    return Results.Ok(new { message = "Vault anahtarï¿½ gï¿½ncellendi." });
});
// --- 5. VAULT: CRUD OPERASYONLARI ---
string vaultDb = "Data/vault.json";

app.MapGet("/api/vault/{owner}", async (string owner) => {
    if (!File.Exists(vaultDb)) return Results.Ok(new List<VaultItem>());
    var all = JsonSerializer.Deserialize<List<VaultItem>>(await File.ReadAllTextAsync(vaultDb)) ?? new List<VaultItem>();
    return Results.Ok(all.Where(a => a.Owner == owner).ToList());
});


app.MapPut("/api/vault/update", async (VaultItem item) => {
    if (!File.Exists(vaultDb)) return Results.NotFound();
    var vault = JsonSerializer.Deserialize<List<VaultItem>>(await File.ReadAllTextAsync(vaultDb)) ?? new List<VaultItem>();
    var existing = vault.FirstOrDefault(v => v.Id == item.Id);
    if (existing == null) return Results.NotFound();

    existing.Title = item.Title;
    existing.EncryptedValue = item.EncryptedValue;
    existing.Category = item.Category;
    existing.UpdatedAt = DateTime.Now;

    await File.WriteAllTextAsync(vaultDb, JsonSerializer.Serialize(vault, new JsonSerializerOptions { WriteIndented = true }));
    return Results.Ok(new { message = "Varlï¿½k gï¿½ncellendi." });
});app.MapPost("/api/vault/add", async (VaultItem item) => {
    var vault = File.Exists(vaultDb) ? JsonSerializer.Deserialize<List<VaultItem>>(await File.ReadAllTextAsync(vaultDb)) ?? new List<VaultItem>() : new List<VaultItem>();
    item.UpdatedAt = DateTime.Now;
    vault.Add(item);
    await File.WriteAllTextAsync(vaultDb, JsonSerializer.Serialize(vault, new JsonSerializerOptions { WriteIndented = true }));
    return Results.Ok(new { message = "Varlï¿½k mï¿½hï¿½rlendi." });
});

app.MapDelete("/api/vault/delete/{id}", async (Guid id) => {
    if (!File.Exists(vaultDb)) return Results.NotFound();
    var vault = JsonSerializer.Deserialize<List<VaultItem>>(await File.ReadAllTextAsync(vaultDb)) ?? new List<VaultItem>();
    var item = vault.FirstOrDefault(v => v.Id == id);
    if (item == null) return Results.NotFound();
    
    vault.Remove(item);
    await File.WriteAllTextAsync(vaultDb, JsonSerializer.Serialize(vault, new JsonSerializerOptions { WriteIndented = true }));
    return Results.Ok(new { message = "Varlï¿½k imha edildi." });
});

// --- 6. AUTH: Åï¿½FRE KURTARMA & SIFIRLAMA ---
app.MapPost("/api/auth/forgot-password", async (ForgotPasswordRequest req, AuthService auth, EmailService emailService) => {
    var users = await auth.GetUsersAsync();
    var user = users.FirstOrDefault(u => u.Email == req.Email);

    if (user == null) return Results.Ok(new { message = "Sï¿½reï¿½ baï¿½latï¿½ldï¿½." });

    user.VerificationCode = auth.GenerateVerificationCode();
    user.VerificationCodeExpiresAt = DateTime.UtcNow.AddMinutes(5);
    await auth.SaveUsersAsync(users);

    var sent = await emailService.SendRecoveryCodeAsync(user.Email, user.VerificationCode);
    if (!sent)
        return Results.Problem("EMAIL_SEND_FAILED");

    return Results.Ok(new { message = "Sï¿½fï¿½rlama kodu gï¿½nderildi." });
});
app.MapPost("/api/user/update-email", async (UpdateEmailRequest request, AuthService auth, SecurityLogService log, HttpContext http) => 
{
    if (request == null || string.IsNullOrWhiteSpace(request.NewEmail))
        return Results.BadRequest(new { message = "Invalid email." });

    if (!Guid.TryParse(request.UserId, out var userGuid))
        return Results.BadRequest(new { message = "Invalid user id." });

    var users = await auth.GetUsersAsync();
    var user = users.FirstOrDefault(u => u.Id == userGuid);
    if (user == null)
        return Results.NotFound(new { message = "User not found." });

    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    var key = $"{user.Id}|{ip}";

    if (IsLocked(key, out var lockedUntil))
        return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);

    if (users.Any(u => u.Id != user.Id && (u.Email ?? "").Trim().ToLowerInvariant() == request.NewEmail.Trim().ToLowerInvariant()))
        return Results.BadRequest(new { message = "Bu e-posta adresi başka bir operatöre ait." });

    if (string.IsNullOrEmpty(user.VerificationCode) || user.VerificationCode != request.Code)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
        return Results.BadRequest(new { message = "Invalid verification code." });
    }

    if (user.VerificationCodeExpiresAt == null || user.VerificationCodeExpiresAt < DateTime.UtcNow)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
        return Results.BadRequest(new { message = "Verification code expired." });
    }

    user.Email = request.NewEmail;
    user.VerificationCode = null;
    user.VerificationCodeExpiresAt = null;

    await auth.SaveUsersAsync(users);

    RegisterSuccess(key);
    await log.LogAsync("EMAIL_UPDATED", user.Id, user.Username, ip, "");

    return Results.Ok(new { message = "EMAIL_UPDATED", newEmail = request.NewEmail });
});
app.MapGet("/api/user/get-profile/{userId}", (string userId) =>
{
    var jsonData = File.ReadAllText(dbPath);
    var users = JsonSerializer.Deserialize<List<User>>(jsonData) ?? new List<User>();
    if (!Guid.TryParse(userId, out var userGuid))
        return Results.BadRequest("Geï¿½ersiz kullanï¿½cï¿½ ID.");

    var user = users.FirstOrDefault(u => u.Id == userGuid);

    if (user == null) return Results.NotFound("Kullanï¿½cï¿½ bulunamadï¿½.");
    return Results.Ok(user);
});

// --- [STEP 1] KURTARMA KODU TALEBï¿½ ---
app.MapPost("/api/auth/request-recovery", async (RecoveryRequest request, EmailService emailService, HttpContext http) => 
{
    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    var email = request.Email?.Trim().ToLowerInvariant() ?? "";
    var key = $"{email}|{ip}";

    if (IsLocked(key, out var lockedUntil))
        return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);

    var jsonData = File.ReadAllText("Data/users.json");
    var users = JsonSerializer.Deserialize<List<User>>(jsonData) ?? new List<User>();

    var user = users.FirstOrDefault(u => (u.Email ?? "").Trim().ToLowerInvariant() == email);

    if (user == null)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
        return Results.NotFound(new { message = "NO_MATCH" });
    }

    string code = new Random().Next(100000, 999999).ToString();
    user.RecoveryCode = code;
    user.RecoveryCodeExpiresAt = DateTime.UtcNow.AddMinutes(5);

    File.WriteAllText("Data/users.json", JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true }));

    var sent = await emailService.SendRecoveryCodeAsync(user.Email, code);
    if (!sent)
        return Results.Problem("EMAIL_SEND_FAILED");

    RegisterSuccess(key);

    return Results.Ok(new { message = "RECOVERY_CODE_CREATED" });
});
app.MapPost("/api/auth/reset-password", (ResetPasswordRequest request, AuthService auth, HttpContext http) => 
{
    var ip = http.Connection.RemoteIpAddress?.ToString() ?? "unknown";

    var jsonData = File.ReadAllText("Data/users.json");
    var users = JsonSerializer.Deserialize<List<User>>(jsonData) ?? new List<User>();
    var user = users.FirstOrDefault(u => u.RecoveryCode == request.Code);

    var emailKey = user?.Email?.Trim().ToLowerInvariant();
    var key = !string.IsNullOrEmpty(emailKey) ? $"{emailKey}|{ip}" : $"ip|{ip}";

    if (IsLocked(key, out var lockedUntil))
        return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);

    if (user == null)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
        return Results.BadRequest(new { message = "INVALID_CODE" });
    }

    if (user.RecoveryCodeExpiresAt == null || user.RecoveryCodeExpiresAt < DateTime.UtcNow)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
        return Results.BadRequest(new { message = "RECOVERY_EXPIRED" });
    }

    if (request.NewPassword != request.ConfirmPassword)
    {
        RegisterFailure(key);
        if (IsLocked(key, out lockedUntil))
            return Results.Json(new { message = "COOLDOWN_ACTIVE", retryAt = lockedUntil }, statusCode: 429);
        return Results.BadRequest(new { message = "PASSWORD_MISMATCH" });
    }

    user.Password = auth.EncryptPassword(request.NewPassword);
    user.RecoveryCode = null;
    user.RecoveryCodeExpiresAt = null;

    File.WriteAllText("Data/users.json", JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true }));
    RegisterSuccess(key);

    return Results.Ok(new { message = "PASSWORD_RESET" });
});



// Gerekli Modeller

app.MapPost("/api/email/test", async (TestEmailRequest req, EmailService emailService) => 
{
    if (string.IsNullOrWhiteSpace(req.Email))
        return Results.BadRequest(new { message = "EMAIL_REQUIRED" });

    var code = new Random().Next(100000, 999999).ToString();
    var sent = await emailService.SendSecurityCodeAsync(req.Email, code);
    if (!sent)
        return Results.Problem("EMAIL_SEND_FAILED");

    return Results.Ok(new { message = "EMAIL_SENT", email = req.Email });
});
if (app.Environment.IsProduction()) 
{
    // API başladığında varsayılan tarayıcıda UI'ı açar
    Process.Start(new ProcessStartInfo("http://localhost:5000/index.html") { UseShellExecute = true });
}
app.Run("http://localhost:5000");