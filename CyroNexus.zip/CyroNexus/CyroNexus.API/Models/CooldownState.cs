namespace CyroNexus.API.Models;

public class CooldownState
{
    public int FailCount { get; set; }
    public DateTime? LockedUntil { get; set; }
}
