namespace CyroNexus.API.Models;

public class User {
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Username { get; set; } = "";
    public string Password { get; set; } = ""; // SHA-256
    public string Email { get; set; } = "";
    public bool IsEmailVerified { get; set; } = false;
    public string? VerificationCode { get; set; }
    public DateTime? VerificationCodeExpiresAt { get; set; }
    public string? RecoveryCode { get; set; }
    public DateTime? RecoveryCodeExpiresAt { get; set; }
    public string? VaultKeyHash { get; set; }
    public string Rank { get; set; } = "Operator";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
