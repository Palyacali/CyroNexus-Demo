namespace CyroNexus.API.Models;

public class VaultItem {
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Owner { get; set; } = "";
    public string Title { get; set; } = "";
    public string EncryptedValue { get; set; } = ""; // AES-256
    public string Category { get; set; } = "General"; // Finans, Sosyal, Özel
    public DateTime UpdatedAt { get; set; } = DateTime.Now;
}