namespace CyroNexus.API.Models;

public class SecurityLog
{
    public DateTime TimestampUtc { get; set; } = DateTime.UtcNow;
    public string Action { get; set; } = "";
    public Guid? UserId { get; set; }
    public string Username { get; set; } = "";
    public string Ip { get; set; } = "";
    public string Details { get; set; } = "";
}
