namespace CyroNexus.API.Models;

public record VerifyRequest(string Email, string Code);
public record LoginRequest(string Username, string Password);
public record UpdateProfileRequest(Guid UserId, string? NewUsername);
public record ForgotPasswordRequest(string Email);
public record ChangePasswordRequest(Guid UserId, string OldPassword, string NewPassword);
public record UpdateVaultKeyRequest(Guid UserId, string OldKey, string NewKey);
public record SendCodeRequest(string UserId, string Target);
public record UpdateEmailRequest(string UserId, string NewEmail, string Code);
public record RecoveryRequest(string Email);
public record ResetPasswordRequest(string Code, string NewPassword, string ConfirmPassword);
public record ResendVerificationRequest(string Email);
public record TestEmailRequest(string Email);
