using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CyroNexus.API.Controllers
{
    [ApiController]
    [Route("api/user")] // URL: http://localhost:5000/api/user
    public class UserController : ControllerBase
    {
        // --- 1. KİMLİK GÜNCELLEME (KULLANICI ADI) ---
        [HttpPut("update-profile")]
        public IActionResult UpdateProfile([FromBody] ProfileUpdateRequest request)
        {
            Console.WriteLine($"\n👤 [PROFILE_UPDATE] ID: {request.UserId} | Yeni İsim: {request.NewUsername}");
            
            if (request == null || string.IsNullOrEmpty(request.NewUsername))
                return BadRequest(new { message = "Geçersiz veri paketi." });

            return Ok(new { message = "KİMLİK_GÜNCELLEME_BAŞARILI." });
        }

        // --- 2. DOĞRULAMA KODU GÖNDERME (E-POSTA) ---
        [HttpPost("send-code")]
        public IActionResult SendCode([FromBody] SendCodeRequest request)
        {
            Console.WriteLine($"\n🌀 [AUTH_SERVICE] Hedef: {request.Target}");

            if (request == null || string.IsNullOrEmpty(request.Target))
                return BadRequest(new { message = "Hedef adres eksik." });

            // 6 haneli fütüristik kod üretimi
            string code = new Random().Next(100000, 999999).ToString();
            
            // SMTP bağlanana kadar terminalden mühürlüyoruz
            Console.WriteLine($">>> ÜRETİLEN_KOD: {code} <<<");

            return Ok(new { message = "Kod terminale iletildi." });
        }

        // --- 3. ŞİFRE DEĞİŞTİRME PROTOKOLÜ ---
        [HttpPost("change-password")]
        public IActionResult ChangePassword([FromBody] PasswordChangeRequest request)
        {
            Console.WriteLine($"\n🔐 [SECURITY] Şifre değişim talebi. ID: {request.UserId}");

            if (string.IsNullOrEmpty(request.NewPassword))
                return BadRequest(new { message = "Yeni şifre boş olamaz." });

            // Burada OldPassword DB kontrolü yapılabilir
            return Ok(new { message = "ŞİFRE_MÜHÜRLENDİ." });
        }

        // --- 4. VAULT KEY YENİDEN MÜHÜRLEME ---
        [HttpPut("update-vault-key")]
        public IActionResult UpdateVaultKey([FromBody] VaultKeyUpdateRequest request)
        {
            Console.WriteLine($"\n🔑 [VAULT_RESEAL] ID: {request.UserId}");
            Console.WriteLine($"> Eski Key: {request.OldKey} | Yeni Key: {request.NewKey}");

            if (string.IsNullOrEmpty(request.NewKey))
                return BadRequest(new { message = "Yeni anahtar boş olamaz." });

            // ÖNEMLİ: Test aşamasında her zaman Ok döner. 
            // DB entegrasyonunda OldKey kontrolü buraya eklenecek.
            return Ok(new { message = "VAULT_ANAHTARI_DEĞİŞTİRİLDİ." });
        }
    }

    // --- 🛠️ VERİ TRANSFER MODELLERİ (PAYLOADS) ---

    public class ProfileUpdateRequest {
        public string UserId { get; set; }
        public string NewUsername { get; set; }
    }

    public class SendCodeRequest {
        public string Target { get; set; }
    }

    public class PasswordChangeRequest {
        public string UserId { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
    }

    public class VaultKeyUpdateRequest {
        public string UserId { get; set; }
        public string OldKey { get; set; }
        public string NewKey { get; set; }
    }
}