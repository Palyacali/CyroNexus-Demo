using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using CyroNexus.API.Models;
using Microsoft.Extensions.Configuration;

namespace CyroNexus.API.Services;

public class AuthService
{
    private readonly string _userDb = "Data/users.json";
    private readonly string _aesKey;
    private static readonly SemaphoreSlim _userDbLock = new(1, 1);

    public AuthService(IConfiguration configuration)
    {
        _aesKey = configuration["Security:AesKey"] ?? "CHANGE_ME_DEFAULT_AES_KEY_32B!";
    }

    // 1. Şifreyi SHA-256 ile Mühürleme
    public string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(bytes);
    }

    public string EncryptPassword(string password)
    {
        return "aes:" + AesEncryption.Encrypt(password, _aesKey);
    }

    public bool VerifyPassword(string storedPassword, string inputPassword)
    {
        if (string.IsNullOrEmpty(storedPassword)) return false;
        if (storedPassword.StartsWith("aes:"))
        {
            var cipher = storedPassword.Substring(4);
            var plain = AesEncryption.Decrypt(cipher, _aesKey);
            return plain == inputPassword;
        }

        var hashed = HashPassword(inputPassword);
        return storedPassword == hashed;
    }

    // 2. Kullanıcıları Listeleme
    public async Task<List<User>> GetUsersAsync()
    {
        await _userDbLock.WaitAsync();
        try
        {
            if (!File.Exists(_userDb)) return new List<User>();
            var json = await File.ReadAllTextAsync(_userDb);
            return JsonSerializer.Deserialize<List<User>>(json) ?? new List<User>();
        }
        finally
        {
            _userDbLock.Release();
        }
    }

    // 3. Kullanıcı Kaydetme
    public async Task SaveUsersAsync(List<User> users)
    {
        await _userDbLock.WaitAsync();
        try
        {
            var json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
            await File.WriteAllTextAsync(_userDb, json);
        }
        finally
        {
            _userDbLock.Release();
        }
    }

    // 4. Doğrulama Kodu Üretme (6 Haneli)
    public string GenerateVerificationCode()
    {
        return new Random().Next(100000, 999999).ToString();
    }
}
