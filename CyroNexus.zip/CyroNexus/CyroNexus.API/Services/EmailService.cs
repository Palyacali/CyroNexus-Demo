using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;

namespace CyroNexus.API.Services;

public sealed class EmailService
{
    private readonly IConfiguration _config;

    public EmailService(IConfiguration config)
    {
        _config = config;
    }

    public Task<bool> SendVerificationCodeAsync(string toEmail, string code)
    {
        var subject = "CYRONEXUS_DOĞRULAMA_KODU";
        var body = BuildCodeBody("DOĞRULAMA_KODU", code);
        return SendAsync(toEmail, subject, body);
    }

    public Task<bool> SendRecoveryCodeAsync(string toEmail, string code)
    {
        var subject = "CYRONEXUS_ŞİFRE_SIFIRLAMA";
        var body = BuildCodeBody("ŞİFRE_SIFIRLAMA_KODU", code);
        return SendAsync(toEmail, subject, body);
    }

    public Task<bool> SendSecurityCodeAsync(string toEmail, string code)
    {
        var subject = "CYRONEXUS_GÜVENLİK_KODU";
        var body = BuildCodeBody("GÜVENLİK_KODU", code);
        return SendAsync(toEmail, subject, body);
    }

    private async Task<bool> SendAsync(string toEmail, string subject, string htmlBody)
    {
        var host = _config["Email:SmtpHost"];
        var portText = _config["Email:SmtpPort"];
        var username = _config["Email:Username"];
        var password = _config["Email:Password"];
        var fromName = _config["Email:FromName"] ?? "CyroNexus";
        var useSslText = _config["Email:UseSsl"];

        if (string.IsNullOrWhiteSpace(host) ||
            string.IsNullOrWhiteSpace(portText) ||
            string.IsNullOrWhiteSpace(username) ||
            string.IsNullOrWhiteSpace(password))
        {
            Console.WriteLine("[MAIL_ERROR] Missing SMTP configuration.");
            return false;
        }

        if (!int.TryParse(portText, out var port)) return false;
        var useSsl = true;
        if (!string.IsNullOrWhiteSpace(useSslText))
        {
            bool.TryParse(useSslText, out useSsl);
        }

        try
        {
            // Gmail app password may include spaces in display; remove them
            password = password.Replace(" ", "");

            using var smtpClient = new SmtpClient(host)
            {
                Port = port,
                Credentials = new NetworkCredential(username, password),
                EnableSsl = useSsl,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false
            };

            using var mailMessage = new MailMessage
            {
                From = new MailAddress(username, fromName),
                Subject = subject,
                Body = htmlBody,
                IsBodyHtml = true,
            };
            mailMessage.To.Add(toEmail);

            await smtpClient.SendMailAsync(mailMessage);
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[MAIL_ERROR] {ex.GetType().Name}: {ex.Message}");
            return false;
        }
    }

    private static string BuildCodeBody(string title, string code)
    {
        return $@"
<div style='background:#050B12;color:#00E5FF;padding:30px;font-family:sans-serif;border:1px solid #00E5FF;'>
  <h2 style='letter-spacing:2px;'>{title}</h2>
  <p style='color:#fff;'>Aşağıdaki kodu kullanın:</p>
  <h1 style='background:rgba(0,229,255,0.1);padding:20px;text-align:center;'>{code}</h1>
  <p style='font-size:10px;'>Bu kod 5 dakika içinde geçersiz olur.</p>
  <hr style='border:0;border-top:1px solid rgba(0,229,255,0.1);'>
  <small>POWERED BY CYROTECH SOFTWARE</small>
</div>";
    }
}
