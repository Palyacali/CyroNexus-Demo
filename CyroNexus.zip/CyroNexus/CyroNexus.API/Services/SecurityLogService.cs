using System.Text.Json;
using CyroNexus.API.Models;

namespace CyroNexus.API.Services;

public class SecurityLogService
{
    private readonly string _logDb = "Data/logs.json";
    private static readonly SemaphoreSlim _logLock = new(1, 1);

    public async Task LogAsync(string action, Guid? userId, string username, string ip, string details)
    {
        await _logLock.WaitAsync();
        try
        {
            List<SecurityLog> logs;
            if (File.Exists(_logDb))
            {
                var json = await File.ReadAllTextAsync(_logDb);
                logs = JsonSerializer.Deserialize<List<SecurityLog>>(json) ?? new List<SecurityLog>();
            }
            else
            {
                logs = new List<SecurityLog>();
            }

            logs.Add(new SecurityLog
            {
                TimestampUtc = DateTime.UtcNow,
                Action = action,
                UserId = userId,
                Username = username ?? "",
                Ip = ip ?? "",
                Details = details ?? ""
            });

            var outJson = JsonSerializer.Serialize(logs, new JsonSerializerOptions { WriteIndented = true });
            await File.WriteAllTextAsync(_logDb, outJson);
        }
        finally
        {
            _logLock.Release();
        }
    }
}
