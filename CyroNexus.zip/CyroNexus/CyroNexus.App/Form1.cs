using System.Drawing;

namespace CyroNexus.App;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
        TrySetIconFromPng();
    }

    private void TrySetIconFromPng()
    {
        try
        {
            var iconPath = Path.Combine(AppContext.BaseDirectory, "logo.png");
            if (!File.Exists(iconPath)) return;

            using var bmp = new Bitmap(iconPath);
            var hIcon = bmp.GetHicon();
            Icon = Icon.FromHandle(hIcon);
        }
        catch
        {
            // Icon is optional; ignore failures
        }
    }
}
